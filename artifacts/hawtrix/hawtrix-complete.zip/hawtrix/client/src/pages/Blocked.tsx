import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { AlertCircle, LogOut } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

export default function Blocked() {
  const [, setLocation] = useLocation();
  const { logout } = useAuth();

  const handleLogout = async () => {
    try {
      await logout();
      toast.success("Déconnexion réussie");
      setLocation("/");
    } catch (error) {
      toast.error("Erreur lors de la déconnexion");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary flex items-center justify-center">
      <Card className="border-border max-w-md w-full mx-4">
        <div className="p-8 space-y-6 text-center">
          {/* Icon */}
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center">
              <AlertCircle className="w-8 h-8 text-destructive" />
            </div>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-primary">Compte suspendu</h1>
            <p className="text-muted-foreground">
              Votre compte a été temporairement suspendu
            </p>
          </div>

          {/* Message */}
          <div className="bg-secondary rounded-lg p-4 border border-border">
            <p className="text-sm text-foreground">
              Si vous pensez que c'est une erreur, veuillez contacter notre support pour plus d'informations.
            </p>
          </div>

          {/* Actions */}
          <div className="space-y-3 pt-4">
            <Button 
              onClick={() => window.location.href = "https://wa.me/message/ITZ45LLE2RKSM1"}
              className="w-full bg-accent hover:bg-accent/90"
              size="lg"
            >
              Contacter le support
            </Button>
            <Button 
              onClick={handleLogout}
              variant="outline"
              className="w-full gap-2"
              size="lg"
            >
              <LogOut className="w-4 h-4" />
              Déconnexion
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
