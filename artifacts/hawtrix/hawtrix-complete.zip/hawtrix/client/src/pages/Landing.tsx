import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowRight, Shield, TrendingUp, Users } from "lucide-react";

export default function Landing() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <span className="text-accent-foreground font-bold text-sm">H</span>
            </div>
            <span className="font-bold text-lg text-primary">Hawtrix</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition">Fonctionnalités</a>
            <a href="#about" className="text-sm text-muted-foreground hover:text-foreground transition">À propos</a>
            <Button 
              onClick={() => setLocation("/login")}
              variant="outline"
              size="sm"
            >
              Connexion
            </Button>
            <Button 
              onClick={() => setLocation("/register")}
              size="sm"
              className="bg-accent hover:bg-accent/90"
            >
              S'inscrire
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-2">
              <h1 className="text-4xl md:text-5xl font-bold text-primary leading-tight">
                Bienvenue sur <span className="text-accent">Hawtrix</span>
              </h1>
              <p className="text-lg text-muted-foreground">
                La plateforme MLM sécurisée avec vérification 2FA et paiement mobile instantané
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-foreground">
                Rejoignez notre réseau d'entrepreneurs et développez votre activité avec des outils modernes et fiables.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-foreground">
                  <Shield className="w-5 h-5 text-accent" />
                  <span>Sécurité maximale avec vérification 2FA</span>
                </li>
                <li className="flex items-center gap-2 text-foreground">
                  <TrendingUp className="w-5 h-5 text-accent" />
                  <span>Suivi en temps réel de vos performances</span>
                </li>
                <li className="flex items-center gap-2 text-foreground">
                  <Users className="w-5 h-5 text-accent" />
                  <span>Gestion complète de votre réseau</span>
                </li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                onClick={() => setLocation("/register")}
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                Commencer maintenant
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button 
                onClick={() => setLocation("/login")}
                variant="outline"
                size="lg"
              >
                Se connecter
              </Button>
            </div>

            <p className="text-sm text-muted-foreground">
              Inscription gratuite • Paiement sécurisé • Support 24/7
            </p>
          </div>

          {/* Hero Image */}
          <div className="hidden md:flex items-center justify-center">
            <div className="relative w-full aspect-square max-w-md">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-primary/20 rounded-3xl blur-3xl"></div>
              <div className="relative bg-gradient-to-br from-primary to-primary/80 rounded-3xl p-8 text-white flex flex-col items-center justify-center h-full">
                <div className="text-6xl font-bold mb-4">₦</div>
                <p className="text-center text-lg font-semibold">Paiement Mobile</p>
                <p className="text-center text-sm text-white/80 mt-2">TMoney • Flooz</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="container py-20 border-t border-border">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Fonctionnalités principales
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Tout ce dont vous avez besoin pour réussir dans votre activité MLM
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: Shield,
              title: "Vérification 2FA",
              description: "Système de sécurité avancé avec code d'activation pour chaque utilisateur"
            },
            {
              icon: TrendingUp,
              title: "Tableau de Bord",
              description: "Suivi complet de vos performances et de votre réseau en temps réel"
            },
            {
              icon: Users,
              title: "Gestion du Réseau",
              description: "Organisez et gérez votre structure de parrainage facilement"
            }
          ].map((feature, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition">
              <feature.icon className="w-8 h-8 text-accent mb-4" />
              <h3 className="font-semibold text-lg text-primary mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-20 border-t border-border">
        <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à rejoindre Hawtrix ?
          </h2>
          <p className="text-white/80 mb-8 max-w-2xl mx-auto">
            Inscrivez-vous maintenant et commencez votre parcours entrepreneurial avec notre plateforme sécurisée
          </p>
          <Button 
            onClick={() => setLocation("/register")}
            size="lg"
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            S'inscrire gratuitement
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 py-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>&copy; 2026 Hawtrix. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
}
