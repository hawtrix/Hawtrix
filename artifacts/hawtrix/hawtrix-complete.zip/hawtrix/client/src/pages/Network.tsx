import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Users, TrendingUp, Share2 } from "lucide-react";
import { toast } from "sonner";

export default function Network() {
  const [, setLocation] = useLocation();

  const handleShareCode = () => {
    navigator.clipboard.writeText("HAW-123456");
    toast.success("Code copié");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center h-16">
          <button 
            onClick={() => setLocation("/dashboard")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Retour</span>
          </button>
        </div>
      </header>

      <div className="container py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">Mon réseau MLM</h1>
          <p className="text-muted-foreground">Gérez votre structure de parrainage et suivez vos performances</p>
        </div>

        {/* Network Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Filleuls directs</p>
                <p className="text-3xl font-bold text-primary">0</p>
              </div>
              <Users className="w-10 h-10 text-accent" />
            </div>
          </Card>

          <Card className="border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Réseau total</p>
                <p className="text-3xl font-bold text-primary">0</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent" />
            </div>
          </Card>

          <Card className="border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Commissions</p>
                <p className="text-3xl font-bold text-accent">0 FCFA</p>
              </div>
              <Share2 className="w-10 h-10 text-accent" />
            </div>
          </Card>
        </div>

        {/* Share Code Section */}
        <Card className="border-border p-8 bg-gradient-to-br from-accent/5 to-primary/5 mb-12">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-bold text-primary">Partagez votre code</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Invitez vos amis à rejoindre Hawtrix avec votre code personnel et commencez à construire votre réseau
            </p>
            <div className="flex justify-center">
              <div className="p-4 bg-background rounded-lg border-2 border-accent">
                <p className="text-center font-mono font-bold text-2xl text-accent">HAW-123456</p>
              </div>
            </div>
            <Button 
              onClick={handleShareCode}
              className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2"
              size="lg"
            >
              <Share2 className="w-4 h-4" />
              Copier et partager
            </Button>
          </div>
        </Card>

        {/* Network Tree */}
        <Card className="border-border p-6">
          <h2 className="text-xl font-bold text-primary mb-6">Votre structure de réseau</h2>
          <div className="text-center py-12 text-muted-foreground">
            <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Aucun filleul pour le moment</p>
            <p className="text-sm">Commencez à partager votre code pour construire votre réseau</p>
          </div>
        </Card>
      </div>
    </div>
  );
}
