import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { useState, useRef, useEffect } from "react";
import { ArrowLeft, Shield } from "lucide-react";
import { toast } from "sonner";

export default function Verify2FA() {
  const [, setLocation] = useLocation();
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleChange = (index: number, value: string) => {
    // Only allow numbers
    const numValue = value.replace(/[^0-9]/g, "").slice(-1);
    const newOtp = [...otp];
    newOtp[index] = numValue;
    setOtp(newOtp);

    // Auto-focus next input
    if (numValue && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const code = otp.join("");
    if (code.length !== 6) {
      toast.error("Veuillez entrer le code complet à 6 chiffres");
      return;
    }

    setLoading(true);
    try {
      // TODO: Call tRPC verify2FA procedure
      toast.success("Compte activé avec succès !");
      setTimeout(() => {
        setLocation("/dashboard");
      }, 1500);
    } catch (error) {
      toast.error("Code invalide. Veuillez réessayer.");
      setOtp(["", "", "", "", "", ""]);
      inputRefs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center h-16">
          <button 
            onClick={() => setLocation("/payment")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Retour</span>
          </button>
        </div>
      </header>

      <div className="container py-12">
        <div className="max-w-md mx-auto">
          <Card className="border-border">
            <div className="p-8 space-y-8">
              {/* Icon */}
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-accent/80 flex items-center justify-center">
                  <Shield className="w-8 h-8 text-white" />
                </div>
              </div>

              {/* Title */}
              <div className="text-center space-y-2">
                <h1 className="text-3xl font-bold text-primary">Vérification 2FA</h1>
                <p className="text-muted-foreground">
                  Entrez le code d'activation à 6 chiffres envoyé par l'administrateur
                </p>
              </div>

              <form onSubmit={handleVerify} className="space-y-8">
                {/* OTP Input */}
                <div className="flex gap-2 justify-center">
                  {otp.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => { inputRefs.current[index] = el; }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      className={`w-12 h-14 text-center text-2xl font-bold rounded-lg border-2 transition focus:outline-none ${
                        digit
                          ? "border-accent bg-accent/5 text-foreground"
                          : "border-border bg-background text-muted-foreground"
                      }`}
                    />
                  ))}
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit"
                  disabled={loading}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  size="lg"
                >
                  {loading ? "Activation en cours..." : "Activer mon compte"}
                </Button>

                {/* Help Text */}
                <div className="text-center space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Vous n'avez pas reçu le code ?
                  </p>
                  <button
                    type="button"
                    className="text-accent hover:underline text-sm font-semibold"
                  >
                    Contacter le support
                  </button>
                </div>
              </form>

              {/* Info Box */}
              <div className="p-4 bg-secondary rounded-lg border border-border">
                <p className="text-xs text-muted-foreground">
                  <span className="font-semibold text-foreground">Important :</span> Ce code a été généré automatiquement par notre système et envoyé à l'administrateur après votre paiement.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
