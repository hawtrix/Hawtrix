import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { LogOut, Lock, Unlock, Copy, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface User {
  id: number;
  phone: string;
  name: string;
  isBlocked: boolean;
  isActive: boolean;
  createdAt: string;
}

export default function Admin() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Accès non autorisé</p>
          <Button onClick={() => setLocation("/")} className="bg-accent hover:bg-accent/90">
            Retour à l'accueil
          </Button>
        </div>
      </div>
    );
  }

  const handleLogout = async () => {
    try {
      await logout();
      toast.success("Déconnexion réussie");
      setLocation("/");
    } catch (error) {
      toast.error("Erreur lors de la déconnexion");
    }
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    toast.success("Code copié");
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleBlockUser = async (userId: number) => {
    try {
      // TODO: Call tRPC admin.blockUser
      toast.success("Utilisateur bloqué");
    } catch (error) {
      toast.error("Erreur lors du blocage");
    }
  };

  const handleUnblockUser = async (userId: number) => {
    try {
      // TODO: Call tRPC admin.unblockUser
      toast.success("Utilisateur débloqué");
    } catch (error) {
      toast.error("Erreur lors du déblocage");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b border-border bg-gradient-to-r from-primary to-primary/80 sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
              <span className="text-primary font-bold text-sm">A</span>
            </div>
            <span className="font-bold text-lg text-white">Hawtrix Admin</span>
          </div>
          <Button 
            onClick={handleLogout}
            variant="outline"
            size="sm"
            className="gap-2 text-white border-white hover:bg-white/10"
          >
            <LogOut className="w-4 h-4" />
            Déconnexion
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">Gestion des utilisateurs</h1>
          <p className="text-muted-foreground">Gérez les comptes, bloquez/débloquez les utilisateurs et générez les codes 2FA</p>
        </div>

        {/* Users Table */}
        <Card className="border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-secondary border-b border-border">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Utilisateur</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Téléphone</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Statut</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Code 2FA</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {users.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">
                      Aucun utilisateur trouvé
                    </td>
                  </tr>
                ) : (
                  users.map((u) => (
                    <tr key={u.id} className="hover:bg-secondary/50 transition">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-semibold text-foreground">{u.name}</p>
                          <p className="text-xs text-muted-foreground">{new Date(u.createdAt).toLocaleDateString()}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-foreground">{u.phone}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${u.isActive ? "bg-green-500" : "bg-gray-400"}`}></div>
                          <span className="text-sm text-foreground">
                            {u.isActive ? "Actif" : "Inactif"}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => handleCopyCode(`2FA-${u.id}`)}
                          className="flex items-center gap-2 text-accent hover:text-accent/80 transition"
                        >
                          {copiedCode === `2FA-${u.id}` ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                          <span className="text-xs font-mono">2FA-{u.id}</span>
                        </button>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          {u.isBlocked ? (
                            <Button
                              onClick={() => handleUnblockUser(u.id)}
                              size="sm"
                              variant="outline"
                              className="gap-1"
                            >
                              <Unlock className="w-3 h-3" />
                              Débloquer
                            </Button>
                          ) : (
                            <Button
                              onClick={() => handleBlockUser(u.id)}
                              size="sm"
                              variant="outline"
                              className="gap-1 text-destructive hover:text-destructive"
                            >
                              <Lock className="w-3 h-3" />
                              Bloquer
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Pending Notifications */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-primary mb-6">Notifications en attente</h2>
          <Card className="border-border p-6">
            <p className="text-muted-foreground text-center py-8">
              Aucune notification en attente
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
