import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { useState } from "react";
import { ArrowLeft, Copy, Check } from "lucide-react";
import { toast } from "sonner";

const PAYMENT_METHODS = [
  {
    id: "tmoney",
    label: "TMoney",
    provider: "Togocom",
    number: "+22891015682",
    color: "#E53E3E",
    ussd: "*145#",
  },
  {
    id: "flooz",
    label: "Flooz",
    provider: "Moov Africa",
    number: "+22897076040",
    color: "#2563EB",
    ussd: "*155#",
  },
];

export default function Payment() {
  const [, setLocation] = useLocation();
  const [selectedMethod, setSelectedMethod] = useState("tmoney");
  const [senderPhone, setSenderPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  const method = PAYMENT_METHODS.find(m => m.id === selectedMethod)!;

  const handleCopyNumber = (number: string) => {
    navigator.clipboard.writeText(number);
    setCopiedNumber(number);
    toast.success("Numéro copié dans le presse-papier");
    setTimeout(() => setCopiedNumber(null), 2000);
  };

  const handleConfirmPayment = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!senderPhone || senderPhone.length < 8) {
      toast.error("Veuillez entrer un numéro valide");
      return;
    }

    setLoading(true);
    try {
      // TODO: Call tRPC payment procedure
      toast.success("Paiement enregistré. Redirection...");
      setTimeout(() => {
        setLocation("/verify-2fa");
      }, 1500);
    } catch (error) {
      toast.error("Erreur lors de l'enregistrement du paiement");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center h-16">
          <button 
            onClick={() => setLocation("/register")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Retour</span>
          </button>
        </div>
      </header>

      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* Amount Card */}
          <Card className="mb-8 bg-gradient-to-r from-primary to-primary/80 border-0 text-white">
            <div className="p-8 text-center">
              <p className="text-sm opacity-90 mb-2">Montant à payer</p>
              <h2 className="text-5xl font-bold mb-2">2 000 FCFA</h2>
              <p className="text-sm opacity-75">Accès à vie • Toute la plateforme</p>
            </div>
          </Card>

          <Card className="border-border">
            <div className="p-8 space-y-8">
              <div>
                <h1 className="text-3xl font-bold text-primary mb-2">Activation du compte</h1>
                <p className="text-muted-foreground">Paiement manuel · 2 000 FCFA</p>
              </div>

              <form onSubmit={handleConfirmPayment} className="space-y-8">
                {/* Step 1: Choose Method */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-primary">Étape 1 : Choisissez votre opérateur</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {PAYMENT_METHODS.map(op => (
                      <button
                        key={op.id}
                        type="button"
                        onClick={() => setSelectedMethod(op.id)}
                        className={`p-4 rounded-lg border-2 transition ${
                          selectedMethod === op.id
                            ? "border-accent bg-accent/5"
                            : "border-border hover:border-accent/50"
                        }`}
                      >
                        <div className="text-center">
                          <p className="font-semibold text-foreground">{op.label}</p>
                          <p className="text-xs text-muted-foreground">{op.provider}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Step 2: Make Payment */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-primary">Étape 2 : Effectuez le paiement</h3>
                  <p className="text-muted-foreground">
                    Faites un transfert de 2 000 FCFA vers le numéro ci-dessous.
                  </p>

                  <div className="bg-secondary rounded-lg p-4 border border-border space-y-3">
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Numéro destinataire {method.label}</p>
                      <button
                        type="button"
                        onClick={() => handleCopyNumber(method.number)}
                        className="w-full flex items-center justify-between p-3 bg-background rounded-lg border border-border hover:border-accent transition"
                      >
                        <span className="font-bold text-lg" style={{ color: method.color }}>
                          {method.number}
                        </span>
                        {copiedNumber === method.number ? (
                          <Check className="w-5 h-5 text-green-500" />
                        ) : (
                          <Copy className="w-5 h-5 text-muted-foreground" />
                        )}
                      </button>
                    </div>

                    <div className="pt-2 border-t border-border">
                      <p className="text-xs text-muted-foreground mb-2">Code USSD</p>
                      <p className="font-mono font-semibold text-foreground">
                        Composez le <span className="text-accent">{method.ussd}</span> pour effectuer la transaction
                      </p>
                    </div>
                  </div>
                </div>

                {/* Step 3: Confirm */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-primary">Étape 3 : Votre numéro de transaction</h3>
                  <p className="text-muted-foreground">
                    Entrez le numéro avec lequel vous venez de payer
                  </p>

                  <div className="space-y-2">
                    <Label htmlFor="senderPhone">Numéro de paiement</Label>
                    <div className="flex gap-2">
                      <div className="flex items-center px-3 bg-secondary rounded-lg border border-border text-muted-foreground font-semibold">
                        🇹🇬 +228
                      </div>
                      <Input
                        id="senderPhone"
                        placeholder="XX XX XX XX"
                        value={senderPhone}
                        onChange={(e) => setSenderPhone(e.target.value)}
                        className="flex-1"
                        maxLength={12}
                      />
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit"
                  disabled={loading}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  size="lg"
                >
                  {loading ? "Traitement..." : "J'ai effectué le paiement"}
                </Button>

                {/* Info */}
                <p className="text-xs text-muted-foreground text-center">
                  Votre inscription sera validée manuellement après vérification du paiement.
                </p>
              </form>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
