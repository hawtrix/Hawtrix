import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { useState } from "react";
import { ArrowLeft, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

export default function Login() {
  const [, setLocation] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    phone: "",
    password: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.phone || !formData.password) {
      toast.error("Veuillez remplir tous les champs");
      return;
    }

    setLoading(true);
    try {
      // TODO: Call tRPC login procedure
      toast.success("Connexion réussie");
      setTimeout(() => {
        setLocation("/dashboard");
      }, 1500);
    } catch (error) {
      toast.error("Identifiants invalides");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center h-16">
          <button 
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Retour</span>
          </button>
        </div>
      </header>

      <div className="container py-12">
        <div className="max-w-md mx-auto">
          <Card className="border-border">
            <div className="p-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-primary mb-2">Se connecter</h1>
                <p className="text-muted-foreground">Accédez à votre compte Hawtrix</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Phone Field */}
                <div className="space-y-2">
                  <Label htmlFor="phone">Téléphone</Label>
                  <div className="flex gap-2">
                    <div className="flex items-center px-3 bg-secondary rounded-lg border border-border text-muted-foreground font-semibold">
                      🇹🇬 +228
                    </div>
                    <Input
                      id="phone"
                      name="phone"
                      placeholder="XX XX XX XX"
                      value={formData.phone}
                      onChange={handleChange}
                      className="flex-1"
                      maxLength={12}
                      required
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div className="space-y-2">
                  <Label htmlFor="password">Mot de passe</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Votre mot de passe"
                      value={formData.password}
                      onChange={handleChange}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit"
                  disabled={loading}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  size="lg"
                >
                  {loading ? "Connexion en cours..." : "Se connecter"}
                </Button>

                {/* Register Link */}
                <p className="text-center text-sm text-muted-foreground">
                  Vous n'avez pas de compte ?{" "}
                  <button
                    type="button"
                    onClick={() => setLocation("/register")}
                    className="text-accent hover:underline font-semibold"
                  >
                    S'inscrire
                  </button>
                </p>
              </form>

              {/* Info Box */}
              <div className="mt-8 p-4 bg-secondary rounded-lg border border-border">
                <p className="text-xs text-muted-foreground">
                  <span className="font-semibold text-foreground">Besoin d'aide ?</span> Contactez notre support pour réinitialiser votre mot de passe.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
