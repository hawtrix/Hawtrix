import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { LogOut, Users, TrendingUp, Settings } from "lucide-react";
import { toast } from "sonner";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    try {
      await logout();
      toast.success("Déconnexion réussie");
      setLocation("/");
    } catch (error) {
      toast.error("Erreur lors de la déconnexion");
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <span className="text-accent-foreground font-bold text-sm">H</span>
            </div>
            <span className="font-bold text-lg text-primary">Hawtrix</span>
          </div>
          <nav className="flex items-center gap-4">
            <button 
              onClick={() => setLocation("/profile")}
              className="text-sm text-muted-foreground hover:text-foreground transition"
            >
              Profil
            </button>
            <button 
              onClick={() => setLocation("/network")}
              className="text-sm text-muted-foreground hover:text-foreground transition"
            >
              Réseau
            </button>
            <Button 
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Déconnexion
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-primary mb-2">
            Bienvenue, {user.name}
          </h1>
          <p className="text-muted-foreground">
            Gérez votre compte et suivez vos performances
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Statut du compte</p>
                <p className="text-2xl font-bold text-primary">Actif</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
            </div>
          </Card>

          <Card className="border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Membres du réseau</p>
                <p className="text-2xl font-bold text-primary">0</p>
              </div>
              <Users className="w-10 h-10 text-accent" />
            </div>
          </Card>

          <Card className="border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Revenus</p>
                <p className="text-2xl font-bold text-accent">0 FCFA</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent" />
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-border p-6">
            <h2 className="text-lg font-semibold text-primary mb-4">Actions rapides</h2>
            <div className="space-y-3">
              <Button 
                onClick={() => setLocation("/profile")}
                variant="outline"
                className="w-full justify-start"
              >
                <Settings className="w-4 h-4 mr-2" />
                Modifier mon profil
              </Button>
              <Button 
                onClick={() => setLocation("/network")}
                variant="outline"
                className="w-full justify-start"
              >
                <Users className="w-4 h-4 mr-2" />
                Voir mon réseau
              </Button>
            </div>
          </Card>

          <Card className="border-border p-6 bg-gradient-to-br from-accent/5 to-primary/5">
            <h2 className="text-lg font-semibold text-primary mb-4">Partager votre code</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Invitez vos amis à rejoindre Hawtrix avec votre code de parrainage
            </p>
            <div className="p-3 bg-background rounded-lg border border-border mb-3">
              <p className="text-center font-mono font-bold text-accent">HAW-{user.id}</p>
            </div>
            <Button 
              onClick={() => {
                navigator.clipboard.writeText(`HAW-${user.id}`);
                toast.success("Code copié");
              }}
              className="w-full bg-accent hover:bg-accent/90"
            >
              Copier le code
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
