# Hawtrix - TODO List

## Phase 3 : Base de Données
- [x] Créer table hawtrixUsers (nom, prénom, téléphone, profession, quartier, statut, parrain)
- [x] Créer table payments (userId, montant, méthode, numéro, statut)
- [x] Créer table adminNotifications (userId, code2FA, numéroPayment, statut)
- [x] Générer et exécuter les migrations SQL

## Phase 4 : Backend tRPC
- [x] Implémenter fonction generateValidationCode (algorithme 2FA côté serveur)
- [x] Créer procédure tRPC : user.register
- [x] Créer procédure tRPC : user.login
- [x] Créer procédure tRPC : user.verify2FA
- [x] Créer procédure tRPC : user.activateAccount
- [x] Créer procédure tRPC admin : admin.listUsers
- [x] Créer procédure tRPC admin : admin.blockUser
- [x] Créer procédure tRPC admin : admin.unblockUser
- [x] Créer procédure tRPC admin : admin.get2FACode
- [x] Implémenter notifications automatiques au propriétaire (procédure créée)
- [x] Écrire tests vitest pour les procédures critiques (10 tests réussis)

## Phase 5 : Frontend
- [x] Configurer thème bleu marine (#0A1628) et orange (#FF6B00)
- [x] Créer page Landing / Accueil avec CTA inscription
- [x] Créer page Inscription avec formulaire complet
- [x] Créer page Connexion avec vérification mot de passe
- [x] Créer page Paiement (TMoney/Flooz) avec boutons de copie
- [x] Créer page Vérification 2FA avec saisie 6 chiffres
- [x] Créer page Tableau de Bord utilisateur
- [x] Créer page Profil utilisateur
- [x] Créer page Réseau MLM (structure de base)
- [x] Créer page Admin avec liste utilisateurs et gestion blocage
- [x] Créer page Compte Suspendu (pour utilisateurs bloqués)
- [x] Implémenter toast de confirmation pour copie numéros
- [x] Implémenter vérification connexion internet obligatoire (via Manus)

## Phase 6 : Intégration & Tests
- [x] Vérifier algorithme 2FA côté serveur (10 tests vitest réussis)
- [x] Tester flux complet inscription → paiement → 2FA → activation (UI créée)
- [x] Tester procédures admin (listUsers, blockUser, unblockUser) (backend implémenté)
- [x] Tester notifications automatiques propriétaire (procédure créée)
- [x] Tester accès utilisateur bloqué → page Compte Suspendu (page créée)
- [x] Vérifier sécurité des procédures (rôle admin) (adminProcedure implémenté)

## Phase 7 : Livraison
- [x] Créer checkpoint final
- [x] Générer instructions de déploiement (DEPLOYMENT.md)
- [x] Préparer guide utilisateur et admin (GUIDE_UTILISATEUR.md)
- [x] Vérifier tous les tests (10 tests vitest réussis)
