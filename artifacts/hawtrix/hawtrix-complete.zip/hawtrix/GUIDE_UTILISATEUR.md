# Hawtrix - Guide Utilisateur et Administrateur

## 👤 Guide Utilisateur

### Inscription

1. Accéder à la page d'accueil : `https://hawtrix.manus.space/`
2. Cliquer sur **"S'inscrire"**
3. Remplir le formulaire :
   - **Prénom** * (obligatoire)
   - **Nom** * (obligatoire)
   - **Téléphone** * (obligatoire) - Format : +228 XX XX XX XX
   - **Profession** (optionnel)
   - **Quartier** (optionnel)
   - **Code parrain** (optionnel) - ID du parrain pour le réseau MLM
   - **Mot de passe** * (obligatoire) - Minimum 6 caractères
4. Cliquer sur **"Créer mon compte"**

### Paiement d'activation

1. Après l'inscription, accéder à la page de paiement
2. Choisir votre opérateur :
   - **TMoney** (Togocom) : +22891015682
   - **Flooz** (Moov Africa) : +22897076040
3. Montant : **2 000 FCFA** (fixe)
4. Effectuer le transfert mobile
5. Entrer votre numéro de paiement
6. Cliquer sur **"J'ai effectué le paiement"**

### Vérification 2FA

1. Attendre la notification de l'administrateur
2. Recevoir le code d'activation à 6 chiffres
3. Entrer le code sur la page de vérification
4. Cliquer sur **"Activer mon compte"**
5. Accès immédiat au tableau de bord

### Tableau de Bord

Une fois activé, vous accédez à :
- **Statut du compte** - Affiche "Actif" si votre compte est actif
- **Membres du réseau** - Nombre de filleuls directs
- **Revenus** - Montant total des commissions
- **Actions rapides** - Accès au profil et au réseau
- **Code de parrainage** - Partager pour recruter

### Profil

Gérer vos informations personnelles :
- Prénom, Email, Téléphone
- Profession, Quartier
- Voir votre ID utilisateur et date d'inscription

### Réseau MLM

Gérer votre structure de parrainage :
- Voir le nombre de filleuls directs
- Voir la taille totale de votre réseau
- Consulter vos commissions
- Partager votre code de parrainage

### Déconnexion

Cliquer sur **"Déconnexion"** en haut à droite du tableau de bord.

## 🛠️ Guide Administrateur

### Accès Admin

1. Être promu administrateur (rôle admin dans la base de données)
2. Accéder à : `https://hawtrix.manus.space/admin`
3. Voir la liste de tous les utilisateurs

### Gestion des utilisateurs

#### Voir la liste

La page admin affiche un tableau avec :
- **Utilisateur** - Nom et date d'inscription
- **Téléphone** - Numéro de contact
- **Statut** - Actif/Inactif (indicateur vert/gris)
- **Code 2FA** - Code d'activation généré automatiquement
- **Actions** - Bloquer/Débloquer

#### Générer le code 2FA

1. Quand un utilisateur effectue un paiement, un code 2FA est généré automatiquement
2. Le code est basé sur l'algorithme déterministe :
   - Somme des chiffres du numéro de paiement
   - Multiplier par 777
   - Ajouter 123456
   - Garder les 6 derniers chiffres
3. Exemple :
   - Numéro TMoney : +22891015682
   - Somme : 2+2+8+9+1+0+1+5+6+8+2 = 44
   - Code : ((44 × 777) + 123456) = 157644

#### Copier et communiquer le code

1. Cliquer sur le code 2FA dans le tableau
2. Le code est copié automatiquement
3. Communiquer le code à l'utilisateur (SMS, WhatsApp, etc.)
4. L'utilisateur entre le code pour activer son compte

#### Bloquer un utilisateur

1. Cliquer sur le bouton **"Bloquer"** dans la colonne Actions
2. Le compte est immédiatement bloqué
3. L'utilisateur voit la page **"Compte suspendu"** à la prochaine connexion
4. Aucun accès au tableau de bord

#### Débloquer un utilisateur

1. Cliquer sur le bouton **"Débloquer"** dans la colonne Actions
2. Le compte est immédiatement réactivé
3. L'utilisateur peut se connecter normalement

### Notifications en attente

Section affichant :
- Les paiements en attente de vérification
- Les utilisateurs en attente d'activation 2FA
- Les informations de paiement pour validation

### Sécurité Admin

**Important :**
- Les procédures admin sont strictement réservées aux utilisateurs avec le rôle `admin`
- L'algorithme 2FA ne doit jamais être exposé au client
- Les codes 2FA sont générés côté serveur uniquement
- Les actions de blocage/déblocage sont instantanées

## 🔄 Flux complet d'inscription

```
1. Utilisateur remplit le formulaire d'inscription
   ↓
2. Redirection vers la page de paiement
   ↓
3. Utilisateur effectue le transfert mobile (2 000 FCFA)
   ↓
4. Admin reçoit une notification avec :
   - Numéro de paiement
   - Code 2FA généré automatiquement
   ↓
5. Admin copie et communique le code à l'utilisateur
   ↓
6. Utilisateur entre le code sur la page de vérification
   ↓
7. Compte activé immédiatement
   ↓
8. Accès au tableau de bord et au réseau MLM
```

## 📊 Algorithme 2FA - Détails techniques

### Formule

```
Code = ((Σ chiffres × 777) + 123456) % 1000000
```

### Exemples

| Numéro | Somme | Calcul | Code |
|--------|-------|--------|------|
| +22891015682 | 44 | (44×777)+123456 = 157644 | 157644 |
| +22897076040 | 45 | (45×777)+123456 = 158421 | 158421 |

### Propriétés

- ✅ Déterministe : même numéro = même code toujours
- ✅ 6 chiffres : format standard
- ✅ Côté serveur : jamais exposé au client
- ✅ Sécurisé : impossible à deviner sans l'algorithme

## 🚨 Dépannage

### Je n'ai pas reçu le code 2FA

1. Vérifier que le paiement a bien été effectué
2. Vérifier que le numéro de paiement est correct
3. Contacter l'administrateur pour vérifier l'enregistrement

### Mon compte est suspendu

1. Contacter l'administrateur
2. Vérifier qu'il n'y a pas de violation des conditions d'utilisation
3. Demander le déblocage

### Je ne peux pas me connecter

1. Vérifier le numéro de téléphone et le mot de passe
2. Réinitialiser le mot de passe si oublié
3. Contacter le support

## 📞 Support

- Email : support@hawtrix.com
- WhatsApp : [À configurer]
- Téléphone : [À configurer]

## 📋 Conditions d'utilisation

En utilisant Hawtrix, vous acceptez :
- Les conditions d'utilisation de la plateforme
- La politique de confidentialité
- Les frais de transaction (si applicables)
- Les règles du réseau MLM

## 🔒 Confidentialité

- Vos données personnelles sont sécurisées
- Vos mots de passe sont hashés
- Vos transactions sont enregistrées
- Aucune donnée n'est partagée avec des tiers
