# Hawtrix - Guide Push Git et Génération APK

## 📱 Transformation en React Native (Expo)

Ce guide explique comment convertir le projet web Hawtrix en application mobile native avec génération APK.

### Prérequis

```bash
# Installer les outils globaux
npm install -g expo-cli eas-cli

# Vérifier les versions
expo --version
eas --version
```

### Étape 1 : Initialiser le projet Expo

```bash
# Créer un nouveau projet Expo avec le template Bare
npx create-expo-app hawtrix-mobile

# Ou convertir le projet existant
cd /home/ubuntu/hawtrix
npx expo install
```

### Étape 2 : Configurer app.json

```json
{
  "expo": {
    "name": "Hawtrix",
    "slug": "hawtrix",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "userInterfaceStyle": "light",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#0A1628"
    },
    "assetBundlePatterns": ["**/*"],
    "ios": {
      "supportsTabletMode": true,
      "bundleIdentifier": "com.hawtrix.app"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#0A1628"
      },
      "package": "com.hawtrix.app",
      "permissions": ["INTERNET", "ACCESS_NETWORK_STATE"]
    },
    "web": {
      "favicon": "./assets/favicon.png"
    },
    "plugins": [
      [
        "expo-build-properties",
        {
          "android": {
            "usesCleartextTraffic": true
          }
        }
      ]
    ]
  }
}
```

### Étape 3 : Initialiser EAS

```bash
# Créer un compte Expo (si nécessaire)
expo login
# ou
eas login

# Initialiser EAS pour le projet
eas init --id com.hawtrix.app
```

### Étape 4 : Configurer eas.json

```json
{
  "cli": {
    "version": ">= 5.0.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal"
    },
    "production": {
      "distribution": "store"
    }
  },
  "submit": {
    "production": {
      "android": {
        "serviceAccount": "~/.android/service-account.json",
        "track": "internal"
      }
    }
  }
}
```

### Étape 5 : Générer l'APK localement

#### Option A : Build local (recommandé pour développement)

```bash
# Installer les dépendances
pnpm install

# Générer l'APK pour Android
eas build --platform android --local

# L'APK sera généré dans : ./dist/
```

#### Option B : Build sur les serveurs EAS (recommandé pour production)

```bash
# Build de développement
eas build --platform android --profile development

# Build de production
eas build --platform android --profile production
```

### Étape 6 : Tester l'APK

```bash
# Télécharger l'APK depuis EAS
# Puis installer sur un appareil Android
adb install hawtrix-app.apk

# Ou via Expo Go (développement)
expo start
# Scanner le QR code avec Expo Go
```

## 🔄 Workflow Git complet

### 1. Configuration initiale

```bash
cd /home/ubuntu/hawtrix

# Initialiser le repository
git init

# Ajouter tous les fichiers
git add .

# Commit initial
git commit -m "Initial commit: Hawtrix fullstack platform with web and mobile support"

# Ajouter le remote
git remote add origin https://github.com/YOUR_USERNAME/hawtrix.git

# Renommer la branche
git branch -M main

# Push vers GitHub
git push -u origin main
```

### 2. Structure des branches

```
main (production)
├── develop (développement)
├── feature/mobile-apk
├── feature/admin-panel
└── feature/mlm-network
```

### 3. Workflow de développement

```bash
# Créer une branche de feature
git checkout -b feature/mobile-apk

# Faire les modifications
# ... editer les fichiers ...

# Commit
git add .
git commit -m "feat: add mobile APK support with Expo"

# Push
git push origin feature/mobile-apk

# Créer une Pull Request sur GitHub
# Après review, merger dans develop
git checkout develop
git pull origin develop
git merge feature/mobile-apk
git push origin develop

# Merger dans main pour production
git checkout main
git pull origin main
git merge develop
git push origin main
```

### 4. Versioning sémantique

```bash
# Créer des tags pour les releases
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0

# Format : v{MAJOR}.{MINOR}.{PATCH}
# v1.0.0 = Release initiale
# v1.0.1 = Bug fix
# v1.1.0 = Nouvelle feature
# v2.0.0 = Breaking changes
```

## 📦 Publier sur Google Play Store

### Prérequis

1. Créer un compte Google Play Developer ($25 une fois)
2. Créer une clé de signature Android

### Générer la clé de signature

```bash
# Créer le keystore
keytool -genkey -v -keystore hawtrix.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias hawtrix-key

# Convertir en base64 pour EAS
base64 hawtrix.keystore > hawtrix.keystore.b64
```

### Configurer EAS pour la publication

```bash
# Ajouter la clé à EAS
eas credentials

# Sélectionner Android
# Sélectionner Keystore
# Uploader hawtrix.keystore
```

### Soumettre à Google Play

```bash
# Build pour production
eas build --platform android --profile production

# Soumettre automatiquement
eas submit --platform android --latest

# Ou soumettre manuellement
# 1. Télécharger l'APK depuis EAS
# 2. Aller sur Google Play Console
# 3. Créer une nouvelle app
# 4. Uploader l'APK
# 5. Remplir les informations (description, screenshots, etc.)
# 6. Soumettre pour review
```

## 🚀 CI/CD avec GitHub Actions

Créer `.github/workflows/build.yml` :

```yaml
name: Build APK

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm install -g eas-cli && pnpm install
      
      - name: Build APK
        run: eas build --platform android --profile production
        env:
          EXPO_TOKEN: ${{ secrets.EXPO_TOKEN }}
      
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: hawtrix-app.apk
          path: ./dist/
```

## 📊 Checklist de déploiement

- [ ] Tester sur appareil Android réel
- [ ] Vérifier les permissions Android
- [ ] Configurer les icônes et splash screens
- [ ] Tester la connexion internet obligatoire
- [ ] Vérifier l'algorithme 2FA
- [ ] Tester le flux complet (inscription → paiement → 2FA)
- [ ] Configurer les notifications push
- [ ] Tester les procédures admin
- [ ] Vérifier la sécurité (pas d'algorithme 2FA exposé)
- [ ] Générer l'APK final
- [ ] Tester l'installation via APK
- [ ] Publier sur Google Play Store
- [ ] Publier sur Apple App Store (iOS)

## 🔗 Ressources

- [Expo Documentation](https://docs.expo.dev)
- [EAS Build Guide](https://docs.expo.dev/build/introduction/)
- [Google Play Console](https://play.google.com/console)
- [GitHub Actions](https://github.com/features/actions)

## 📝 Notes importantes

1. **Certificat de signature** : Conserver le keystore en sécurité
2. **Tokens d'accès** : Utiliser des secrets GitHub, jamais de tokens en dur
3. **Versioning** : Incrémenter la version avant chaque build
4. **Testing** : Toujours tester sur appareil réel avant publication
5. **Monitoring** : Configurer Sentry ou Bugsnag pour les crashs

## 🎯 Prochaines étapes

1. ✅ Configurer Expo et EAS
2. ✅ Générer l'APK localement
3. ✅ Tester sur appareil Android
4. ✅ Publier sur Google Play Store
5. ✅ Configurer CI/CD avec GitHub Actions
6. ✅ Publier sur Apple App Store (iOS)
