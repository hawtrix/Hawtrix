import { describe, it, expect } from "vitest";

/**
 * Test suite for Hawtrix 2FA algorithm
 */
describe("Hawtrix 2FA Algorithm", () => {
  /**
   * Generate 2FA code using deterministic algorithm
   * Code = ((sum of payment phone digits * 777) + 123456), keep last 6 digits with zero-padding
   */
  function generateValidationCode(phone: string): string {
    if (!phone) return "000000";
    const digits = phone.replace(/[^0-9]/g, "");
    let sum = 0;
    for (let i = 0; i < digits.length; i++) {
      sum += parseInt(digits[i], 10);
    }
    const code = (sum * 777) + 123456;
    return code.toString().slice(-6).padStart(6, "0");
  }

  it("should generate correct 2FA code for TMoney number +22891015682", () => {
    const code = generateValidationCode("+22891015682");
    // Sum of digits: 2+2+8+9+1+0+1+5+6+8+2 = 44
    // (44 * 777) + 123456 = 34188 + 123456 = 157644
    // Last 6 digits: 157644
    expect(code).toBe("157644");
  });

  it("should generate correct 2FA code for Flooz number +22897076040", () => {
    const code = generateValidationCode("+22897076040");
    // Sum of digits: 2+2+8+9+7+0+7+6+0+4+0 = 45
    // (45 * 777) + 123456 = 34965 + 123456 = 158421
    // Last 6 digits: 158421
    expect(code).toBe("158421");
  });

  it("should zero-pad codes with less than 6 digits", () => {
    const code = generateValidationCode("123");
    // Sum of digits: 1+2+3 = 6
    // (6 * 777) + 123456 = 4662 + 123456 = 128118
    // Last 6 digits: 128118
    expect(code).toHaveLength(6);
    expect(code).toMatch(/^\d{6}$/);
  });

  it("should handle empty phone number", () => {
    const code = generateValidationCode("");
    expect(code).toBe("000000");
  });

  it("should handle phone with non-digit characters", () => {
    const code = generateValidationCode("+228-9101-5682");
    // Should extract only digits: 22891015682
    // Same as TMoney test
    expect(code).toBe("157644");
  });

  it("should always return exactly 6 digits", () => {
    const testNumbers = [
      "+22891015682",
      "+22897076040",
      "123",
      "999999999",
      "",
    ];
    
    testNumbers.forEach(number => {
      const code = generateValidationCode(number);
      expect(code).toHaveLength(6);
      expect(code).toMatch(/^\d{6}$/);
    });
  });
});

/**
 * Test suite for password hashing
 */
describe("Password Hashing", () => {
  function hashPassword(password: string): string {
    const crypto = require("crypto");
    return crypto.createHash("sha256").update(password).digest("hex");
  }

  function verifyPassword(password: string, hash: string): boolean {
    return hashPassword(password) === hash;
  }

  it("should hash password consistently", () => {
    const password = "TestPassword123";
    const hash1 = hashPassword(password);
    const hash2 = hashPassword(password);
    expect(hash1).toBe(hash2);
  });

  it("should verify correct password", () => {
    const password = "TestPassword123";
    const hash = hashPassword(password);
    expect(verifyPassword(password, hash)).toBe(true);
  });

  it("should reject incorrect password", () => {
    const password = "TestPassword123";
    const hash = hashPassword(password);
    expect(verifyPassword("WrongPassword", hash)).toBe(false);
  });

  it("should generate different hashes for different passwords", () => {
    const hash1 = hashPassword("Password1");
    const hash2 = hashPassword("Password2");
    expect(hash1).not.toBe(hash2);
  });
});
