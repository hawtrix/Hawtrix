import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, hawtrixUsers, InsertHawtrixUser, HawtrixUser, payments, InsertPayment, adminNotifications, InsertAdminNotification } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Hawtrix User Queries
 */
export async function createHawtrixUser(data: InsertHawtrixUser): Promise<HawtrixUser> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(hawtrixUsers).values(data);
  const id = result[0].insertId as number;
  const user = await db.select().from(hawtrixUsers).where(eq(hawtrixUsers.id, id)).limit(1);
  return user[0]!;
}

export async function getHawtrixUserByUserId(userId: number): Promise<HawtrixUser | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(hawtrixUsers).where(eq(hawtrixUsers.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getHawtrixUserById(id: number): Promise<HawtrixUser | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(hawtrixUsers).where(eq(hawtrixUsers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateHawtrixUser(id: number, data: Partial<HawtrixUser>): Promise<HawtrixUser | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  await db.update(hawtrixUsers).set(data).where(eq(hawtrixUsers.id, id));
  return getHawtrixUserById(id);
}

export async function blockHawtrixUser(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(hawtrixUsers).set({ isBlocked: true }).where(eq(hawtrixUsers.id, id));
}

export async function unblockHawtrixUser(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(hawtrixUsers).set({ isBlocked: false }).where(eq(hawtrixUsers.id, id));
}

export async function getAllHawtrixUsers(): Promise<HawtrixUser[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(hawtrixUsers);
}

/**
 * Payment Queries
 */
export async function createPayment(data: InsertPayment): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(payments).values(data);
  return result[0];
}

export async function getPaymentById(id: number): Promise<any> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getPaymentsByUserId(userId: number): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(payments).where(eq(payments.userId, userId));
}

export async function updatePaymentStatus(id: number, status: string, verificationCode?: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updateData: any = { status };
  if (verificationCode) updateData.verificationCode = verificationCode;
  
  await db.update(payments).set(updateData).where(eq(payments.id, id));
}

/**
 * Admin Notification Queries
 */
export async function createAdminNotification(data: InsertAdminNotification): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(adminNotifications).values(data);
  return result[0];
}

export async function getAdminNotificationsByStatus(status: 'pending' | 'sent' | 'verified'): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(adminNotifications).where(eq(adminNotifications.status, status));
}

export async function updateAdminNotificationStatus(id: number, status: 'pending' | 'sent' | 'verified'): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(adminNotifications).set({ status }).where(eq(adminNotifications.id, id));
}

// TODO: add feature queries here as your schema grows.
