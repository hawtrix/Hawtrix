import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import {
  createHawtrixUser,
  getHawtrixUserByUserId,
  getHawtrixUserById,
  blockHawtrixUser,
  unblockHawtrixUser,
  getAllHawtrixUsers,
  createPayment,
  getPaymentsByUserId,
  updatePaymentStatus,
  createAdminNotification,
  getAdminNotificationsByStatus,
  updateAdminNotificationStatus,
} from "../db";
import { upsertUser } from "../db";
import crypto from "crypto";

/**
 * Generate 2FA code using deterministic algorithm
 * Code = ((sum of payment phone digits * 777) + 123456), keep last 6 digits with zero-padding
 */
function generateValidationCode(phone: string): string {
  if (!phone) return "000000";
  const digits = phone.replace(/[^0-9]/g, "");
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    sum += parseInt(digits[i], 10);
  }
  const code = (sum * 777) + 123456;
  return code.toString().slice(-6).padStart(6, "0");
}

/**
 * Hash password using bcrypt-like approach (for demo, using crypto)
 */
function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

/**
 * Verify password
 */
function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

/**
 * Admin procedure - only accessible to admin users
 */
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const hawtrixRouter = router({
  /**
   * User Registration
   * Creates a new Hawtrix user with payment information
   */
  register: publicProcedure
    .input(
      z.object({
        name: z.string().min(1),
        surname: z.string().min(1),
        phone: z.string().min(8),
        profession: z.string().optional(),
        neighborhood: z.string().optional(),
        referrerId: z.number().optional(),
        password: z.string().min(6),
        paymentMethod: z.enum(["tmoney", "flooz"]),
        paymentPhone: z.string().min(8),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Create core user first (if not already authenticated)
        let userId = ctx.user?.id;
        
        if (!userId) {
          // For public registration, we need to create a temporary user
          // In production, this would be handled differently
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "User must be authenticated to register",
          });
        }

        // Create Hawtrix user profile
        const hashedPassword = hashPassword(input.password);
        const hawtrixUser = await createHawtrixUser({
          userId,
          phone: input.phone,
          surname: input.surname,
          profession: input.profession || null,
          neighborhood: input.neighborhood || null,
          referrerId: input.referrerId || null,
          password: hashedPassword,
          isActive: false, // Not active until payment verified
          isBlocked: false,
        });

        // Create payment record
        const payment = await createPayment({
          userId,
          hawtrixUserId: hawtrixUser.id,
          amount: "2000.00" as any, // Fixed amount in FCFA
          method: input.paymentMethod as "tmoney" | "flooz",
          senderPhone: input.paymentPhone,
          status: "pending" as any,
        });

        // Generate 2FA code
        const code2FA = generateValidationCode(input.paymentPhone);

        // Create admin notification
        await createAdminNotification({
          userId,
          hawtrixUserId: hawtrixUser.id,
          paymentId: payment.insertId as number,
          paymentPhone: input.paymentPhone,
          code2FA,
          method: input.paymentMethod as "tmoney" | "flooz",
          status: "pending",
        });

        return {
          success: true,
          hawtrixUserId: hawtrixUser.id,
          paymentId: payment.insertId,
          message: "Registration successful. Awaiting payment verification.",
        };
      } catch (error) {
        console.error("[Hawtrix] Registration error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Registration failed",
        });
      }
    }),

  /**
   * User Login
   * Authenticates user with phone and password
   */
  login: publicProcedure
    .input(
      z.object({
        phone: z.string().min(8),
        password: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // Find user by phone (this would need a query helper)
        // For now, we'll return a placeholder
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid credentials",
        });
      } catch (error) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Login failed",
        });
      }
    }),

  /**
   * Verify 2FA Code
   * Validates the 2FA code sent by admin
   */
  verify2FA: publicProcedure
    .input(
      z.object({
        hawtrixUserId: z.number(),
        code: z.string().length(6),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const hawtrixUser = await getHawtrixUserById(input.hawtrixUserId);
        if (!hawtrixUser) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "User not found",
          });
        }

        // Get pending admin notification
        const notifications = await getAdminNotificationsByStatus("pending");
        const notification = notifications.find(
          (n) => n.hawtrixUserId === input.hawtrixUserId
        );

        if (!notification) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "No pending verification found",
          });
        }

        // Verify code
        if (notification.code2FA !== input.code) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Invalid verification code",
          });
        }

        // Update payment status
        await updatePaymentStatus(notification.paymentId, "verified", input.code);

        // Update admin notification status
        await updateAdminNotificationStatus(notification.id, "verified");

        // Activate user
        await updateHawtrixUser(input.hawtrixUserId, { isActive: true });

        return {
          success: true,
          message: "Account activated successfully",
        };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[Hawtrix] 2FA verification error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Verification failed",
        });
      }
    }),

  /**
   * Get User Profile
   * Returns the authenticated user's Hawtrix profile
   */
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    try {
      const hawtrixUser = await getHawtrixUserByUserId(ctx.user!.id);
      if (!hawtrixUser) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "User profile not found",
        });
      }
      return hawtrixUser;
    } catch (error) {
      if (error instanceof TRPCError) throw error;
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to fetch profile",
      });
    }
  }),

  /**
   * Admin: List All Users
   * Returns all Hawtrix users (admin only)
   */
  admin: router({
    listUsers: adminProcedure.query(async () => {
      try {
        return await getAllHawtrixUsers();
      } catch (error) {
        console.error("[Hawtrix] List users error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch users",
        });
      }
    }),

    /**
     * Admin: Block User
     * Blocks a user account
     */
    blockUser: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        try {
          await blockHawtrixUser(input.userId);
          return { success: true, message: "User blocked successfully" };
        } catch (error) {
          console.error("[Hawtrix] Block user error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to block user",
          });
        }
      }),

    /**
     * Admin: Unblock User
     * Unblocks a user account
     */
    unblockUser: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        try {
          await unblockHawtrixUser(input.userId);
          return { success: true, message: "User unblocked successfully" };
        } catch (error) {
          console.error("[Hawtrix] Unblock user error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to unblock user",
          });
        }
      }),

    /**
     * Admin: Get 2FA Code
     * Returns the 2FA code for a payment
     */
    get2FACode: adminProcedure
      .input(z.object({ paymentPhone: z.string() }))
      .query(async ({ input }) => {
        try {
          const code = generateValidationCode(input.paymentPhone);
          return { code };
        } catch (error) {
          console.error("[Hawtrix] Get 2FA code error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to generate code",
          });
        }
      }),

    /**
     * Admin: Get Pending Notifications
     * Returns all pending payment notifications
     */
    getPendingNotifications: adminProcedure.query(async () => {
      try {
        return await getAdminNotificationsByStatus("pending");
      } catch (error) {
        console.error("[Hawtrix] Get pending notifications error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch notifications",
        });
      }
    }),
  }),
});

// Import updateHawtrixUser for use in verify2FA
import { updateHawtrixUser } from "../db";

// Export for use in main router
export default hawtrixRouter;
