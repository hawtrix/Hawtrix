CREATE TABLE `adminNotifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`hawtrixUserId` int NOT NULL,
	`paymentId` int NOT NULL,
	`paymentPhone` varchar(20) NOT NULL,
	`code2FA` varchar(6) NOT NULL,
	`method` enum('tmoney','flooz') NOT NULL,
	`status` enum('pending','sent','verified') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `adminNotifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `hawtrixUsers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phone` varchar(20) NOT NULL,
	`surname` varchar(100),
	`profession` varchar(100),
	`neighborhood` varchar(100),
	`referrerId` int,
	`isActive` boolean NOT NULL DEFAULT true,
	`isBlocked` boolean NOT NULL DEFAULT false,
	`password` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `hawtrixUsers_id` PRIMARY KEY(`id`),
	CONSTRAINT `hawtrixUsers_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`hawtrixUserId` int NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`method` enum('tmoney','flooz') NOT NULL,
	`senderPhone` varchar(20) NOT NULL,
	`status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
	`verificationCode` varchar(6),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`)
);
