import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Hawtrix-specific user profile extending the core users table
 * Stores MLM-specific information like phone, profession, neighborhood, referrer
 */
export const hawtrixUsers = mysqlTable("hawtrixUsers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(), // Foreign key to users.id
  phone: varchar("phone", { length: 20 }).notNull(),
  surname: varchar("surname", { length: 100 }),
  profession: varchar("profession", { length: 100 }),
  neighborhood: varchar("neighborhood", { length: 100 }),
  referrerId: int("referrerId"), // Foreign key to hawtrixUsers.id (optional referrer)
  isActive: boolean("isActive").default(true).notNull(),
  isBlocked: boolean("isBlocked").default(false).notNull(),
  password: varchar("password", { length: 255 }).notNull(), // Hashed password
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HawtrixUser = typeof hawtrixUsers.$inferSelect;
export type InsertHawtrixUser = typeof hawtrixUsers.$inferInsert;

/**
 * Payment records for user activation
 * Tracks payment method, amount, and verification status
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  hawtrixUserId: int("hawtrixUserId").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  method: mysqlEnum("method", ["tmoney", "flooz"]).notNull(),
  senderPhone: varchar("senderPhone", { length: 20 }).notNull(),
  status: mysqlEnum("status", ["pending", "verified", "rejected"]).default("pending").notNull(),
  verificationCode: varchar("verificationCode", { length: 6 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * Admin notifications for payment verification
 * Notifies admin about pending payments and provides 2FA code
 */
export const adminNotifications = mysqlTable("adminNotifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  hawtrixUserId: int("hawtrixUserId").notNull(),
  paymentId: int("paymentId").notNull(),
  paymentPhone: varchar("paymentPhone", { length: 20 }).notNull(),
  code2FA: varchar("code2FA", { length: 6 }).notNull(),
  method: mysqlEnum("method", ["tmoney", "flooz"]).notNull(),
  status: mysqlEnum("status", ["pending", "sent", "verified"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminNotification = typeof adminNotifications.$inferSelect;
export type InsertAdminNotification = typeof adminNotifications.$inferInsert;

/**
 * Relations for Drizzle ORM
 */
export const usersRelations = relations(users, ({ many }) => ({
  hawtrixUsers: many(hawtrixUsers),
  payments: many(payments),
  adminNotifications: many(adminNotifications),
}));

export const hawtrixUsersRelations = relations(hawtrixUsers, ({ one, many }) => ({
  user: one(users, {
    fields: [hawtrixUsers.userId],
    references: [users.id],
  }),
  referrer: one(hawtrixUsers, {
    fields: [hawtrixUsers.referrerId],
    references: [hawtrixUsers.id],
  }),
  payments: many(payments),
  adminNotifications: many(adminNotifications),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, {
    fields: [payments.userId],
    references: [users.id],
  }),
  hawtrixUser: one(hawtrixUsers, {
    fields: [payments.hawtrixUserId],
    references: [hawtrixUsers.id],
  }),
}));

export const adminNotificationsRelations = relations(adminNotifications, ({ one }) => ({
  user: one(users, {
    fields: [adminNotifications.userId],
    references: [users.id],
  }),
  hawtrixUser: one(hawtrixUsers, {
    fields: [adminNotifications.hawtrixUserId],
    references: [hawtrixUsers.id],
  }),
  payment: one(payments, {
    fields: [adminNotifications.paymentId],
    references: [payments.id],
  }),
}));

// TODO: Add your tables here