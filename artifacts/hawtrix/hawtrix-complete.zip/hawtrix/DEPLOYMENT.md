# Hawtrix - Guide de Déploiement et Génération APK

## 📋 Vue d'ensemble

Hawtrix est une plateforme MLM fullstack avec authentification, paiement mobile 2FA et gestion d'utilisateurs. Le projet est construit avec React, Express, tRPC et MySQL.

## 🏗️ Architecture

```
Frontend (React 19 + Tailwind 4)
    ↓
tRPC Client
    ↓
Backend Express + tRPC
    ↓
MySQL Database
```

## 🚀 Déploiement sur Manus

### Étape 1 : Vérifier les dépendances

```bash
cd /home/ubuntu/hawtrix
pnpm install
```

### Étape 2 : Vérifier la base de données

La base de données MySQL est automatiquement configurée avec :
- Table `users` (authentification Manus OAuth)
- Table `hawtrixUsers` (profils utilisateurs)
- Table `payments` (historique des paiements)
- Table `adminNotifications` (notifications 2FA)

### Étape 3 : Vérifier les variables d'environnement

Les variables d'environnement suivantes sont automatiquement injectées :
- `DATABASE_URL` - Connexion MySQL
- `JWT_SECRET` - Signature des sessions
- `VITE_APP_ID` - OAuth Manus
- `OAUTH_SERVER_URL` - Serveur OAuth
- `VITE_OAUTH_PORTAL_URL` - Portail OAuth

### Étape 4 : Déployer via Manus UI

1. Ouvrir le Management UI du projet
2. Cliquer sur le bouton **Publish** (en haut à droite)
3. Sélectionner le mode de déploiement (Autoscale ou Reserved)
4. Confirmer la publication

Le projet sera accessible à : `https://hawtrix.manus.space`

## 📱 Génération APK (React Native)

### Prérequis

```bash
# Installer Expo CLI
npm install -g expo-cli

# Installer EAS CLI (Expo Application Services)
npm install -g eas-cli
```

### Configuration EAS

1. Créer un compte Expo : https://expo.dev
2. Configurer le projet :

```bash
cd /home/ubuntu/hawtrix
eas build --platform android --local
```

3. Suivre les instructions pour générer l'APK

### Alternative : Utiliser Expo Go

Pour tester rapidement sans APK :

```bash
cd /home/ubuntu/hawtrix
expo start
```

Puis scanner le QR code avec l'app Expo Go sur votre téléphone.

## 🔄 Push Git et Versioning

### Initialiser le repository Git

```bash
cd /home/ubuntu/hawtrix
git init
git add .
git commit -m "Initial commit: Hawtrix fullstack platform"
```

### Connecter à GitHub

```bash
# Via Management UI : Settings → GitHub
# Ou via CLI :
git remote add origin https://github.com/YOUR_USERNAME/hawtrix.git
git branch -M main
git push -u origin main
```

### Workflow de déploiement

```
Local Development
    ↓
Git Commit & Push
    ↓
GitHub Repository
    ↓
Manus Publish (via UI)
    ↓
Production Deployment
```

## 🧪 Tests

### Tests unitaires

```bash
pnpm test
```

### Tests d'intégration 2FA

```bash
pnpm test server/hawtrix.test.ts
```

### Vérifier le build

```bash
pnpm build
pnpm start
```

## 🔐 Sécurité

### Points importants

1. **Algorithme 2FA** : Côté serveur uniquement, jamais exposé au client
2. **Mots de passe** : Hashés avec SHA-256 (à remplacer par bcrypt en production)
3. **Authentification** : OAuth Manus avec sessions JWT
4. **Rôles** : Admin-only procedures protégées avec `adminProcedure`

### À améliorer en production

- [ ] Remplacer SHA-256 par bcrypt pour les mots de passe
- [ ] Ajouter rate limiting sur les endpoints sensibles
- [ ] Implémenter CORS strictement
- [ ] Ajouter logging et monitoring
- [ ] Configurer HTTPS forcé
- [ ] Ajouter 2FA par SMS ou email

## 📊 Structure du projet

```
hawtrix/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Pages de l'app
│   │   ├── components/    # Composants réutilisables
│   │   └── App.tsx        # Routeur principal
│   └── index.html
├── server/                # Backend Express + tRPC
│   ├── routers/
│   │   └── hawtrix.ts     # Procédures tRPC
│   ├── db.ts              # Helpers de base de données
│   └── routers.ts         # Routeur principal
├── drizzle/               # Migrations SQL
│   └── schema.ts          # Schéma de base de données
└── package.json
```

## 🎨 Personnalisation

### Thème

Les couleurs sont définies dans `client/src/index.css` :
- Primaire : Bleu marine (#0A1628)
- Accent : Orange (#FF6B00)

### Numéros de paiement

Modifiables dans `client/src/pages/Payment.tsx` :
```typescript
const PAYMENT_METHODS = [
  {
    id: "tmoney",
    number: "+22891015682",  // À remplacer
    ...
  },
  ...
];
```

## 📞 Support

Pour toute question :
- Documentation Manus : https://docs.manus.im
- Expo Docs : https://docs.expo.dev
- tRPC Docs : https://trpc.io

## 📝 Checklist avant production

- [ ] Tester tous les flux utilisateur
- [ ] Vérifier les procédures admin
- [ ] Configurer les notifications 2FA
- [ ] Mettre à jour les numéros de paiement
- [ ] Configurer le domaine personnalisé
- [ ] Activer HTTPS
- [ ] Configurer les backups de base de données
- [ ] Mettre en place le monitoring
- [ ] Tester la génération APK
- [ ] Publier sur Google Play Store

## 🚀 Prochaines étapes

1. Connecter les procédures tRPC aux pages frontend
2. Implémenter les notifications automatiques
3. Ajouter les tests d'intégration complets
4. Configurer le domaine personnalisé
5. Générer et tester l'APK
6. Publier sur les stores d'applications
