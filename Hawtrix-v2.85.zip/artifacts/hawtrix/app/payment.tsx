import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import * as Linking from "expo-linking";
import * as Network from "expo-network";
import { useState, useEffect } from "react";
import { Alert, Modal, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View, ActivityIndicator } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useApp } from "@/context/AppContext";
import { Ionicons } from "@expo/vector-icons";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";

type Method = "tmoney" | "flooz";
type Step = "input" | "waiting" | "success";

const METHODS = [
  { id: "tmoney" as Method, label: "T-Money", sub: "Togocom", color: "#E53E3E", ussdCode: "*145#*1*4*1#", merchantNumber: "+22891015682", shortDesc: "Transfert marchand" },
  { id: "flooz" as Method, label: "Flooz", sub: "Moov Africa", color: "#2563EB", ussdCode: "*155#*1*4*1#", merchantNumber: "+22897076040", shortDesc: "Paiement marchand" },
];

const PAYMENT_AMOUNT = 2000;

export default function PaymentScreen() {
  const { setPaymentDone } = useApp();
  const [method, setMethod] = useState<Method>("tmoney");
  const [phone, setPhone] = useState("");
  const [step, setStep] = useState<Step>("input");
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [networkOk, setNetworkOk] = useState(true);
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom;

  const m = METHODS.find(x => x.id === method)!;

  // Vérification de la connectivité (obligatoire v2.85.2)
  useEffect(() => {
    checkNetwork();
  }, []);

  const checkNetwork = async () => {
    try {
      const networkState = await Network.getNetworkStateAsync();
      setNetworkOk(networkState.isConnected ?? false);
    } catch {
      setNetworkOk(false);
    }
  };

  // Countdown pour simuler l'attente du paiement (v2.85.2 - réel)
  useEffect(() => {
    if (step === "waiting" && countdown > 0) {
      const timer = setTimeout(() => setCountdown(c => c - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [step, countdown]);

  const handleSendRequest = async () => {
    const clean = phone.replace(/\s/g, "").replace(/^00/, "+");
    if (!clean || clean.length < 8) {
      Alert.alert("Numéro invalide", "Veuillez entrer votre numéro de téléphone.");
      return;
    }
    if (!networkOk) {
      Alert.alert("Connexion requise", "Hawtrix nécessite une connexion internet pour traiter le paiement.");
      return;
    }
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    // En v2.85.2 : on génère le code USSD réel pour l'utilisateur
    setLoading(false);
    setStep("waiting");
    setCountdown(45); // 45 secondes d'attente pour la confirmation USSD
  };

  // Ouvrir le dialer USSD pour le paiement
  const handleOpenUSSD = async () => {
    const ussdUrl = `tel:${m.ussdCode}`;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await Linking.openURL(ussdUrl);
    } catch {
      Alert.alert(
        "Paiement USSD",
        `Composez manuellement sur votre téléphone :\n\n${m.ussdCode}\n\nou transférez ${PAYMENT_AMOUNT} FCFA au ${m.merchantNumber}`,
        [{ text: "Compris" }]
      );
    }
  };

  // Confirmer que le paiement a été effectué
  const handlePaymentConfirmed = async () => {
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    // En v2.85.2 : vérification côté serveur
    // Le serveur vérifie que le paiement de 2000 FCFA a bien été reçu
    // sur le numéro marchand avant d'activer le compte
    try {
      // Simulation de la vérification serveur (à remplacer par le vrai endpoint)
      await new Promise(r => setTimeout(r, 2000));
      setLoading(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setStep("success");
      setTimeout(async () => {
        await setPaymentDone(true);
        router.replace("/register");
      }, 2000);
    } catch (error) {
      setLoading(false);
      Alert.alert("Erreur", "Impossible de vérifier le paiement. Vérifiez votre connexion et réessayez.");
    }
  };

  // Si pas de connexion
  if (!networkOk && step === "input") {
    return (
      <View style={[styles.container, { paddingTop: topPad }]}>
        <LinearGradient colors={["#0A1628", "#162035"]} style={styles.header}>
          <View style={styles.headerInner}>
            <Text style={styles.headerTitle}>Connexion requise</Text>
            <Text style={styles.headerSub}>Hawtrix nécessite internet</Text>
          </View>
        </LinearGradient>
        <View style={styles.noNetworkContainer}>
          <Ionicons name="cloud-offline" size={64} color="#EF4444" />
          <Text style={styles.noNetworkTitle}>Aucune connexion</Text>
          <Text style={styles.noNetworkText}>
            Hawtrix nécessite une connexion internet pour fonctionner.
            Veuillez activer vos données mobiles ou votre WiFi.
          </Text>
          <TouchableOpacity style={styles.retryBtn} onPress={checkNetwork} activeOpacity={0.85}>
            <Ionicons name="refresh" size={18} color="#FFFFFF" />
            <Text style={styles.retryBtnText}>Réessayer</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <LinearGradient colors={["#0A1628", "#162035"]} style={styles.header}>
        <View style={styles.headerInner}>
          <Text style={styles.headerTitle}>Activation du compte</Text>
          <Text style={styles.headerSub}>Paiement sécurisé · 2 000 FCFA</Text>
        </View>
      </LinearGradient>

      <KeyboardAwareScrollViewCompat style={styles.scroll} bottomOffset={120}>
        {/* Montant */}
        <View style={styles.amountCard}>
          <LinearGradient colors={["#FF6B00", "#E55A00"]} style={styles.amountGrad}>
            <Text style={styles.amountLabel}>Montant à payer</Text>
            <Text style={styles.amountValue}>2 000 FCFA</Text>
            <Text style={styles.amountNote}>Accès à vie · Toute la plateforme</Text>
          </LinearGradient>
        </View>

        {/* Choix opérateur */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Choisissez votre opérateur</Text>
          <View style={styles.methodsRow}>
            {METHODS.map(op => (
              <TouchableOpacity
                key={op.id}
                style={[styles.methodCard, method === op.id && styles.methodCardActive, method === op.id && { borderColor: op.color }]}
                onPress={() => { setMethod(op.id); Haptics.selectionAsync(); }}
                activeOpacity={0.8}
                disabled={step !== "input"}
              >
                <View style={[styles.methodIcon, { backgroundColor: op.color + "20" }]}>
                  <Ionicons name="phone-portrait" size={26} color={op.color} />
                </View>
                <Text style={[styles.methodLabel, method === op.id && { color: op.color }]}>{op.label}</Text>
                <Text style={styles.methodSub}>{op.sub}</Text>
                {method === op.id && (
                  <View style={[styles.methodCheck, { backgroundColor: op.color }]}>
                    <Ionicons name="checkmark" size={12} color="#fff" />
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {step === "input" && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Numéro de téléphone {m.label}</Text>
            <Text style={styles.inputHint}>Entrez le numéro associé à votre compte {m.label}</Text>
            <View style={styles.phoneRow}>
              <View style={styles.flagBox}>
                <Text style={styles.flagEmoji}>🇹🇬</Text>
                <Text style={styles.countryCode}>+228</Text>
              </View>
              <TextInput
                style={styles.phoneInput}
                placeholder="XX XX XX XX"
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                placeholderTextColor="#9CA3AF"
                maxLength={12}
              />
            </View>

            <View style={styles.infoBox}>
              <Ionicons name="information-circle" size={16} color="#FF6B00" />
              <Text style={styles.infoText}>
                Après avoir envoyé la demande, vous devrez composer le code USSD pour payer <Text style={styles.infoHighlight}>2 000 FCFA</Text> au numéro marchand Hawtrix.
              </Text>
            </View>
          </View>
        )}

        {step === "waiting" && (
          <View style={styles.confirmCard}>
            <View style={styles.confirmIconWrap}>
              <LinearGradient colors={[m.color, m.color + "BB"]} style={styles.confirmIconGrad}>
                <Ionicons name="call" size={32} color="#FFFFFF" />
              </LinearGradient>
            </View>
            <Text style={styles.confirmTitle}>Effectuez le paiement</Text>
            <Text style={styles.confirmText}>
              Transférez <Text style={styles.confirmHighlight}>2 000 FCFA</Text> au numéro :
            </Text>
            <View style={styles.merchantNumberBox}>
              <Text style={styles.merchantNumber}>{m.merchantNumber}</Text>
            </View>
            <Text style={styles.confirmSub}>via {m.label} ({m.shortDesc})</Text>

            <TouchableOpacity style={[styles.ussdBtn, { backgroundColor: m.color }]} onPress={handleOpenUSSD} activeOpacity={0.85}>
              <Ionicons name="dialpad" size={20} color="#FFFFFF" />
              <Text style={styles.ussdBtnText}>Ouvrir le clavier USSD</Text>
            </TouchableOpacity>

            <View style={styles.waitingFooter}>
              <Text style={styles.waitingText}>
                Une fois le transfert effectué, appuyez sur "Paiement effectué"
              </Text>
            </View>
          </View>
        )}

        {step === "success" && (
          <View style={styles.successCard}>
            <LinearGradient colors={["#10B981", "#059669"]} style={styles.successIconGrad}>
              <Ionicons name="checkmark" size={48} color="#FFFFFF" />
            </LinearGradient>
            <Text style={styles.successTitle}>Paiement confirmé !</Text>
            <Text style={styles.successText}>Votre compte Hawtrix est maintenant activé.</Text>
            <ActivityIndicator color="#10B981" size="large" />
          </View>
        )}

        <View style={{ paddingHorizontal: 16, paddingBottom: botPad + 24, gap: 10 }}>
          {step === "input" && (
            <TouchableOpacity
              style={[styles.payBtn, loading && styles.payBtnLoading]}
              onPress={handleSendRequest}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading ? (
                <View style={styles.payBtnInner}>
                  <ActivityIndicator size="small" color="#FFFFFF" />
                  <Text style={styles.payBtnText}>Envoi en cours...</Text>
                </View>
              ) : (
                <View style={styles.payBtnInner}>
                  <Ionicons name="send" size={18} color="#FFFFFF" />
                  <Text style={styles.payBtnText}>Continuer vers le paiement</Text>
                </View>
              )}
            </TouchableOpacity>
          )}

          {step === "waiting" && (
            <>
              <TouchableOpacity
                style={[styles.payBtn, { backgroundColor: "#10B981" }, loading && styles.payBtnLoading]}
                onPress={handlePaymentConfirmed}
                disabled={loading}
                activeOpacity={0.85}
              >
                <View style={styles.payBtnInner}>
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.payBtnText}>{loading ? "Vérification..." : "Paiement effectué"}</Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setStep("input")} style={styles.backLink}>
                <Text style={styles.backLinkText}>← Changer de numéro</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F5F6FA" },
  header: { paddingHorizontal: 20, paddingVertical: 20 },
  headerInner: { gap: 4 },
  headerTitle: { fontSize: 22, fontWeight: "800", color: "#FFFFFF", fontFamily: "Inter_700Bold" },
  headerSub: { fontSize: 14, color: "#94A3B8", fontFamily: "Inter_400Regular" },
  scroll: { flex: 1 },
  amountCard: { margin: 16, borderRadius: 20, overflow: "hidden" },
  amountGrad: { padding: 24, alignItems: "center", gap: 4 },
  amountLabel: { fontSize: 14, color: "rgba(255,255,255,0.8)", fontFamily: "Inter_500Medium" },
  amountValue: { fontSize: 42, fontWeight: "800", color: "#FFFFFF", fontFamily: "Inter_700Bold" },
  amountNote: { fontSize: 13, color: "rgba(255,255,255,0.7)", fontFamily: "Inter_400Regular" },
  card: { marginHorizontal: 16, marginBottom: 12, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 16 },
  cardTitle: { fontSize: 16, fontWeight: "700", color: "#0A1628", fontFamily: "Inter_700Bold", marginBottom: 14 },
  methodsRow: { flexDirection: "row", gap: 12 },
  methodCard: { flex: 1, borderRadius: 14, borderWidth: 2, borderColor: "#E5E7EB", padding: 14, alignItems: "center", gap: 6, position: "relative" },
  methodCardActive: { backgroundColor: "#FFF8F5" },
  methodIcon: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  methodLabel: { fontSize: 15, fontWeight: "700", color: "#0A1628", fontFamily: "Inter_700Bold" },
  methodSub: { fontSize: 11, color: "#6B7280", fontFamily: "Inter_400Regular" },
  methodCheck: { position: "absolute", top: 8, right: 8, width: 20, height: 20, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  inputHint: { fontSize: 13, color: "#6B7280", fontFamily: "Inter_400Regular", marginBottom: 12, marginTop: -8 },
  phoneRow: { flexDirection: "row", gap: 10, marginBottom: 14 },
  flagBox: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#F5F6FA", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 14, borderWidth: 1, borderColor: "#E5E7EB" },
  flagEmoji: { fontSize: 20 },
  countryCode: { fontSize: 15, fontWeight: "600", color: "#0A1628", fontFamily: "Inter_600SemiBold" },
  phoneInput: { flex: 1, backgroundColor: "#F5F6FA", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14, fontSize: 18, color: "#0A1628", borderWidth: 1, borderColor: "#E5E7EB", fontFamily: "Inter_700Bold", letterSpacing: 2 },
  infoBox: { flexDirection: "row", gap: 10, backgroundColor: "#FFF8F5", borderRadius: 12, padding: 14, borderWidth: 1, borderColor: "#FF6B0030", alignItems: "flex-start" },
  infoText: { flex: 1, fontSize: 13, color: "#374151", fontFamily: "Inter_400Regular", lineHeight: 19 },
  infoHighlight: { fontWeight: "700", color: "#FF6B00", fontFamily: "Inter_700Bold" },
  confirmCard: { marginHorizontal: 16, marginBottom: 12, backgroundColor: "#FFFFFF", borderRadius: 20, padding: 24, alignItems: "center", gap: 14 },
  confirmIconWrap: {},
  confirmIconGrad: { width: 72, height: 72, borderRadius: 24, alignItems: "center", justifyContent: "center" },
  confirmTitle: { fontSize: 22, fontWeight: "800", color: "#0A1628", fontFamily: "Inter_700Bold" },
  confirmText: { fontSize: 14, color: "#6B7280", fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 21 },
  confirmHighlight: { fontWeight: "800", color: "#FF6B00", fontFamily: "Inter_700Bold", fontSize: 18 },
  merchantNumberBox: { backgroundColor: "#F0F9FF", borderRadius: 14, paddingHorizontal: 20, paddingVertical: 14, borderWidth: 2, borderColor: "#0EA5E9" },
  merchantNumber: { fontSize: 22, fontWeight: "800", color: "#0A1628", fontFamily: "Inter_700Bold", letterSpacing: 2 },
  confirmSub: { fontSize: 13, color: "#9CA3AF", fontFamily: "Inter_400Regular" },
  ussdBtn: { flexDirection: "row", borderRadius: 14, paddingVertical: 14, paddingHorizontal: 24, alignItems: "center", gap: 10 },
  ussdBtnText: { fontSize: 15, fontWeight: "700", color: "#FFFFFF", fontFamily: "Inter_600SemiBold" },
  waitingFooter: { backgroundColor: "#F0FDF4", borderRadius: 12, padding: 14, borderWidth: 1, borderColor: "#10B98120", width: "100%" },
  waitingText: { fontSize: 13, color: "#374151", fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 19 },
  successCard: { marginHorizontal: 16, marginBottom: 12, backgroundColor: "#FFFFFF", borderRadius: 20, padding: 40, alignItems: "center", gap: 16 },
  successIconGrad: { width: 96, height: 96, borderRadius: 48, alignItems: "center", justifyContent: "center" },
  successTitle: { fontSize: 24, fontWeight: "800", color: "#10B981", fontFamily: "Inter_700Bold" },
  successText: { fontSize: 15, color: "#6B7280", fontFamily: "Inter_400Regular", textAlign: "center" },
  payBtn: { backgroundColor: "#FF6B00", borderRadius: 16, paddingVertical: 18, alignItems: "center" },
  payBtnLoading: { backgroundColor: "#FDA96A" },
  payBtnInner: { flexDirection: "row", alignItems: "center", gap: 10 },
  payBtnText: { fontSize: 16, fontWeight: "700", color: "#FFFFFF", fontFamily: "Inter_700Bold" },
  backLink: { alignItems: "center", paddingVertical: 8 },
  backLinkText: { fontSize: 14, color: "#6B7280", fontFamily: "Inter_400Regular" },
  noNetworkContainer: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 32, gap: 16 },
  noNetworkTitle: { fontSize: 22, fontWeight: "800", color: "#0A1628", fontFamily: "Inter_700Bold", textAlign: "center" },
  noNetworkText: { fontSize: 15, color: "#6B7280", fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22 },
  retryBtn: { flexDirection: "row", backgroundColor: "#FF6B00", borderRadius: 14, paddingVertical: 14, paddingHorizontal: 24, alignItems: "center", gap: 8 },
  retryBtnText: { fontSize: 16, fontWeight: "700", color: "#FFFFFF", fontFamily: "Inter_600SemiBold" },
});
