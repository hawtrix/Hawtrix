import { Redirect } from "expo-router";
import { useApp } from "@/context/AppContext";
import { ActivityIndicator, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import { useEffect, useState } from "react";
import * as Network from "expo-network";

// En v2.85.2 : vérification de connectivité au démarrage
// L'application ne fonctionne plus hors ligne
export default function Index() {
  const { isLoading, termsAccepted, paymentDone, user } = useApp();
  const colors = useColors();
  const [networkOk, setNetworkOk] = useState<boolean | null>(null);

  useEffect(() => {
    checkNetwork();
    // Vérification périodique toutes les 30 secondes
    const interval = setInterval(checkNetwork, 30000);
    return () => clearInterval(interval);
  }, []);

  const checkNetwork = async () => {
    try {
      const networkState = await Network.getNetworkStateAsync();
      setNetworkOk(networkState.isConnected ?? false);
    } catch {
      setNetworkOk(false);
    }
  };

  if (isLoading || networkOk === null) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: colors.navyDark }}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  // Si pas de connexion et pas déjà connecté, on redirige vers la page de connexion
  if (!networkOk && !user) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "#F5F6FA", paddingHorizontal: 32 }}>
        <View style={{ backgroundColor: "#FFFFFF", borderRadius: 24, padding: 32, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.1, shadowRadius: 12, shadowOffset: { width: 0, height: 4 } }}>
          <View style={{ width: 80, height: 80, borderRadius: 40, backgroundColor: "#FEF2F2", alignItems: "center", justifyContent: "center", marginBottom: 20 }}>
            <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: "#EF4444", alignItems: "center", justifyContent: "center" }}>
              <ActivityIndicator size="small" color="#FFFFFF" />
            </View>
          </View>
          <Text style={{ fontSize: 20, fontWeight: "800", color: "#0A1628", fontFamily: "Inter_700Bold", textAlign: "center", marginBottom: 8 }}>
            Hawtrix
          </Text>
          <Text style={{ fontSize: 14, color: "#EF4444", fontFamily: "Inter_600SemiBold", textAlign: "center", marginBottom: 4 }}>
            Connexion internet requise
          </Text>
          <Text style={{ fontSize: 13, color: "#6B7280", fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 19 }}>
            Hawtrix v2.85.2 nécessite une connexion internet pour fonctionner. Veuillez activer vos données mobiles ou votre WiFi.
          </Text>
          <View style={{ marginTop: 20 }}>
            <ActivityIndicator size="large" color="#FF6B00" />
          </View>
        </View>
      </View>
    );
  }

  if (!termsAccepted) return <Redirect href="/welcome" />;
  if (!paymentDone) return <Redirect href="/payment" />;
  if (!user) return <Redirect href="/register" />;
  if (!user.tutorialSeen) return <Redirect href="/tutorial" />;
  return <Redirect href="/(tabs)/home" />;
}
